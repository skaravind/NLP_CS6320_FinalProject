ID : Problem

cgcnty4 : Not related to COVID
e5u2n47 : Not related to COVID
fkmvu72 : Not in english
fkdylpj : Empty
fl8uqd2 : Empty
fjbm4iv : Empty
fkov5et : Empty
fl57p5t : Not related to COVID
dawjixf : Not related to COVID
cy4y93j : Not related to COVID
c0r3283 : Not related to COVID
fl7d8bv : Not in english
cc6hngq : Not related to COVID
e374hbw : Not related to COVID
c4ebl1k : Not related to COVID
c71qn2t : Not related to COVID
coli1n2 : Not related to COVID
coodgtc : Not related to COVID