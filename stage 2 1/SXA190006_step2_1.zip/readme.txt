# Problems with the sentences:

## ID : PROBLEM

fkub1on : Speaker's intentions not clear and has no clear emotions displayed.
fk6m4b8 : Just article headings/links.
c116uge : Talks about the beer Corona, not the virus.
cwgvqti : not related to covid
d6felf3 : not related to covid
fg5dwpy : Just article headings/links.
c38jpz6 : not related to covid